# CLAUDE.md — Suite de programas UserRPL para HP 50g

Contexto de proyecto para continuar el desarrollo de una suite de programas en
UserRPL para una calculadora **HP 50g real** (no emulador), usada en las materias
**Laboratorio de Datos** y **Microeconomía I** (Lic. en Economía, FCE-UNLP), con
extensión planificada a **Matemática I**.

**Entorno de trabajo: Windows.** Los scripts auxiliares están en PowerShell
(`programas/verificar.ps1`, `programas/a-crlf.ps1`).

Todo lo que sigue fue verificado empíricamente en el hardware. Las reglas de la
sección "Reglas de UserRPL" NO son teoría: cada una viene de un bug real que
costó tiempo encontrar.

---

## 1. Formato de archivo y transferencia

Los programas se escriben como archivos `.txt` en la PC y se transfieren con
**Conn4x** a la calculadora.

Requisitos **obligatorios** para que Conn4x lo reconozca como objeto nativo
(programa/lista/matriz) en vez de cargarlo como string inerte:

1. Primera línea exacta: `%%HP: T(3)A(R)F(.);`
2. Terminaciones de línea **CRLF** (`\r\n`), no LF.
3. **ASCII puro de 7 bits** en todo el archivo — ni un byte fuera de 0x00–0x7F,
   ni siquiera dentro de comentarios `@`. Un carácter `Σ` en un comentario
   rompe la transferencia aunque el compilador ignore los comentarios.

Comando para convertir a CRLF al final de cada edición:

```bash
sed 's/$/\r/' archivo_lf.txt > /ruta/salida/ARCHIVO.txt
file /ruta/salida/ARCHIVO.txt   # debe decir: HP text - T(3) A(R) F(.);
```

**Terminología de Conn4x:** "download" = de la PC a la calculadora (al revés de
lo intuitivo).

**Después de cada transferencia:** confirmar el ícono del objeto en `VAR`
(programa / directorio / lista / string) antes de asumir que cargó bien.

### Estructura del archivo

```
%%HP: T(3)A(R)F(.);
DIR
  NOMBREPROG
  \<<
    ... código ...
  \>>
END
```

Un objeto suelto (sin `DIR`, ej. una lista de datos o un helper) va sin el
envoltorio y se guarda directo con `'NOMBRE' STO`.

---

## 2. Reglas de UserRPL (aprendidas a los golpes)

### 2.1 Comandos que NO existen (a pesar de sonar lógicos)

| Escribí esto ❌ | El real es ✅ | Nota |
|---|---|---|
| `ROUND` | `RND` | Necesita 2 args: `valor decimales RND`. Para entero: `0 RND` |
| `SQRT` | `\v/` | Es el símbolo √ en forma ASCII |
| `\GTE` / `\LTE` | `< NOT` / `> NOT` | No existen esos escapes. `A ≥ B` ⇔ `A B < NOT` |
| `>=` / `<=` | `< NOT` / `> NOT` | Mismo caso |

Escapes ASCII **confirmados válidos**: `\->` (flecha), `\<<` `\>>` (programa),
`\v/` (raíz), `\=/` (distinto de), `\GS` (Σ).

Síntoma típico de usar un comando inexistente: el nombre queda **sin evaluar en
la pila** y el error aparece más adelante, en el comando que recibe la basura
(ej. `R\->C ERROR: BAD ARGUMENT TYPE` con `'ROUND'` visible en la pila).

### 2.2 Bloques `\<<` huérfanos ⚠️ (el bug más difícil de detectar)

Un `\<< ... \>>` que **NO** está inmediatamente precedido por una declaración
`\->` **nunca se autoejecuta** — se empuja a la pila como dato inerte (ves el
código entero sentado en el nivel 1).

Es fácil de introducir al sacar una variable `\->` que antes precedía a un `\<<`,
dejándolo huérfano.

**Este bug NO se detecta contando paréntesis** — el total puede seguir cerrando
perfecto. Hay que verificar que cada `\<<` (salvo el que abre el programa entero)
tenga un `\->` en la línea anterior. Ver script en sección 4.

### 2.3 Variables locales vs. globales y `PURGE`

- **Locales** (creadas con `\->`): se autodestruyen al cerrar su scope. Nunca
  hace falta (ni sirve) purgarlas.
- `{ NOMBRE }` con un nombre **LOCAL** evalúa al **VALOR**, no al nombre → `PURGE`
  falla con "bad argument type". Con un nombre **GLOBAL** (creado con
  `'NOMBRE' STO` sin `\->` previo) sí funciona.
- `'NOMBRE' STO` **actualiza el local existente** si ya hay uno en scope con ese
  nombre (no crea un global nuevo). Así se mutan acumuladores dentro de un loop.
- Para armar una lista de 1 elemento desde un local: `VALOR 1 \->LIST`, nunca
  `{ VALOR }` (esto último guarda el nombre sin evaluar).
- **Nunca** guardar un programa dentro de una variable local para invocarlo
  después por nombre — comportamiento inconsistente confirmado. Poner la lógica
  inline en cada punto de uso.

### 2.4 Concatenación de strings (patrón semilla)

```
"Etiqueta: " VALOR \->STR + 10 CHR +     <- semilla SIN + adelante
"Otra: " + VALOR2 \->STR +               <- cada pieza CON su +, incluida la última
MSGBOX
```

- El **primer literal es la semilla** y NO lleva `+` antes (no hay nada con qué
  concatenar todavía). Ponerlo da `+ ERROR: too few arguments`.
- Cada pieza siguiente, **incluida la última antes de `MSGBOX`**, necesita su `+`.
  Olvidar el `+` final deja dos objetos sueltos y `MSGBOX` muestra solo uno
  (bug silencioso: se ve "algo", pero falta texto).

### 2.5 `INFORM` (formularios)

- **Máximo ~4 campos** por pantalla. Con 5, el último queda inalcanzable con las
  flechas. Solución: partir en 2+ pantallas `INFORM` secuenciales.
- Campo **numérico**: `{ "label" "default" 0 }` (3 elementos, el `0` final es el
  código de tipo). Sin ese `0`, el valor vuelve como texto y rompe la aritmética.
- Campo que acepta **lista/vector/algebraico**: `{ "label" "hint" }` (2 elementos).
- El default debe ser un string no vacío como `"0"`, nunca `""` — un campo nunca
  visitado se envía con su default literal.
- `OBJ\-> DROP \-> N1 N2 N3` asigna en el **mismo orden** en que se declararon los
  campos. Invertir el orden es un bug frecuente y silencioso.

### 2.6 `MSGBOX`

- **No hace scroll.** Máximo seguro: **2 líneas de datos SIN encabezado
  decorativo** por caja. Más que eso corta contenido silenciosamente.
- Es **modal** (espera OK), así que varias llamadas seguidas encadenan solas.
  Patrón usado: partir un resumen de 6 líneas en 3 cajas de 2.

### 2.7 `FOR` y modo exacto/aproximado

- Un `FOR` con **inicio > fin no ejecuta ni una vez**; con **inicio = fin ejecuta
  una vez** (no cero — esto causó una "raya fantasma" en un gráfico cuando el
  rango era degenerado).
- Si el orden relativo de dos límites puede variar según el caso (ej. impuesto
  vs. subsidio), calcular explícitamente cuál es menor con IF/THEN/ELSE antes del
  `FOR`.
- Literales enteros pueden generar **fracciones exactas/simbólicas** que los
  comandos gráficos rechazan con "BAD ARGUMENT TYPE". Mitigación: escribir
  literales con punto decimal (`0.` `10.` en vez de `0` `10`) y aplicar `\->NUM`
  antes de usar un valor calculado como coordenada.

### 2.8 Gráficos: `PICT`, `R\->C`, `XRNG`/`YRNG`

- ⚠️ **Una fila con número MÁS GRANDE está FÍSICAMENTE MÁS ARRIBA** en pantalla
  (al revés de la convención top-down típica). Detectado por una pendiente
  invertida en un gráfico de dispersión.
- `XRNG`/`YRNG` **NO son cosméticos**: reescalan de verdad cómo `LINE`/`BOX`/
  `PIXON`/`R\->C` interpretan sus argumentos.
- **Enfoque recomendado** (el que usan las versiones actuales): fijar
  `XRNG`/`YRNG` al **rango real de los datos** y dibujar con **valores reales
  directos**, sin fórmula manual de escalado a píxel. Ventajas: código mucho más
  simple, y el cursor del modo interactivo lee valores reales.
- **No mezclar** coordenadas estilo píxel crudo con un `XRNG`/`YRNG` de rango
  real en el mismo programa. Elegir un enfoque y ser consistente.
- `XRNG` rechaza rangos de **ancho cero** con "bad argument value". Siempre
  poner salvaguarda: `IF XMAX XMIN == THEN XMAX 1. + 'XMAX' STO END`.
- Offsets de marcadores deben ser **proporcionales a la escala**
  (ej. `QMAX 40. /`), no constantes de píxel.
- `GOR` (pegar GROB sobre PICT) necesita **3 argumentos**, con `PICT` primero
  (nivel 3, el más profundo): `PICT grob posicion GOR`.
- `\->GROB` (string → gráfico de texto) es válido.

### 2.9 Camino nativo de graficación (SIN EXPLORAR — pendiente)

Encontrado en un archivo de terceros (`GRAF.txt`), **no probado todavía**:

```
'X^2' 'EQ' STO
-5. 5. XRNG  0. 25. YRNG
ERASE DRAX DRAW LABEL PICTURE
```

`DRAX` = ejes, `DRAW` = grafica la EQ, **`LABEL` = pone los números en los ejes
automáticamente**. Si funciona, es mucho más simple y potente que dibujar con
`LINE` a mano, y resolvería de una el problema de rotular gráficos que
abandonamos. Hay un test listo (`TEST_LABEL.txt`) sin correr.

### 2.10 Evaluación de expresiones algebraicas (CAS)

Confirmado que funciona:

```
'X^2+3' \-> EXPR
\<<
  2 'X' STO
  EXPR EVAL \->NUM     @ da 7
\>>
```

- El usuario debe tipear la expresión **con comillas simples**: `'X^2+3'`.
- Para símbolos sueltos (`<`, `<=`) en un campo, van **con comillas dobles**:
  `"<"`, `"<="` — si no, la calculadora intenta parsearlos como comparación
  algebraica incompleta y tira syntax error.
- Salvaguarda por si el campo devuelve string en vez de algebraico:
  `IF DUP TYPE 2 == THEN STR\-> END`

### 2.11 Matrices como salida tipo tabla

`{ K 6 } \->ARRY` construye una matriz de K filas × 6 columnas a partir de K*6
valores apilados. En **modo algebraico**, `EDIT` sobre esa matriz abre un editor
de celdas tipo planilla (en modo RPN solo edita la matriz plana).

---

## 3. Flujo de trabajo que funciona

1. **Probar aislado antes de confiar.** Ante cualquier comando o técnica nueva,
   escribir un test de 2-5 líneas y correrlo en la calculadora ANTES de meterlo
   en un programa grande. Esto ahorró horas repetidamente.
2. **Editar con `str_replace` de coincidencia exacta**, nunca reconstruir el
   archivo cortando con `head -N` y pegando pedazos — así se perdió un `\<<` en
   un empalme y costó un ciclo entero de debug.
3. **Correr la batería de verificación** (sección 4) antes de cada entrega.
4. **Convertir a CRLF** y verificar con `file`.
5. Si algo funciona en un programa pero falla en otro con patrón similar:
   **sospechar primero de una versión vieja todavía residente en la
   calculadora** antes de asumir un bug nuevo. Pasó dos veces (DBOXPLOT, DOLS).
   Purgar la vieja antes de probar la nueva.

---

## 4. Batería de verificación (correr antes de cada entrega)

**El entorno de trabajo es Windows.** Hay dos scripts de PowerShell en
`programas/`:

```powershell
# Verificar uno o varios archivos
.\verificar.ps1 DBOXPLOT.txt
.\verificar.ps1 *.txt

# Convertir a CRLF + verificar header y ASCII antes de transferir
.\a-crlf.ps1 archivo_editado.txt
```

Si PowerShell bloquea la ejecución:
`powershell -ExecutionPolicy Bypass -File .\verificar.ps1 *.txt`

`verificar.ps1` chequea, en este orden: profundidad de anidación acumulada
(debe cerrar en 0), bloques `\<<` huérfanos, bytes no-ASCII, comandos inválidos
(`SQRT`/`ROUND`/`>=`/`=/=`), comillas balanceadas, header `%%HP`,
terminaciones CRLF, y `FOR`/`NEXT` emparejados.

**Advertencia:** el conteo total de paréntesis **no detecta** un `\<<` mal
ubicado si se compensó con cierres de más en otro lado. Por eso el chequeo de
profundidad acumulada y el de huérfanos son los importantes — un total
balanceado no garantiza nada.

Tras editar un bloque grande, comparar las partes **no tocadas** contra la
versión anterior (`git diff`, o `Compare-Object` en PowerShell) para detectar
truncamientos accidentales.

<details>
<summary>Equivalentes en bash (si alguna vez se trabaja en Linux/WSL)</summary>

```bash
F=archivo.txt

python3 -c "
with open('$F') as f:
    depth = 0; maxd = 0
    for line in f:
        depth += line.count('\\\\<<') - line.count('\\\\>>')
        maxd = max(maxd, depth)
    print('DEPTH FINAL:', depth, '| MAXIMA:', maxd)
"

python3 -c "
with open('$F') as f: lines = f.readlines()
h = [i+1 for i,l in enumerate(lines) if '\\\\<<' in l and i>0 and '\\\\->' not in lines[i-1]]
print('Huerfanos:', h)
"

grep -naP '[^\x00-\x7F]' $F || echo "ASCII OK"
grep -v '^\s*@' $F | grep -cE 'SQRT|ROUND|>=|=/='
sed 's/$/\r/' archivo_lf.txt > SALIDA.txt   # conversion a CRLF
```
</details>

---

## 5. Inventario de programas (16)

### Estadística descriptiva (una variable)

| Programa | Qué hace | Entrada |
|---|---|---|
| `DSTATS` | Media, varianza, desvío, CV | Datos |
| `DMODA` | Moda(s), avisa si no hay | Datos |
| `DPCTIL` | Percentil interpolado `Lp=(p/100)(n+1)`. **Mediana = p50** | Datos + p |
| `DFRECTABLA` | Tabla de frecuencias (abs, acum.abs, %, acum.%) como **matriz** | Datos + K + Ancho + Inicio |
| `DHISTO` | Histograma (barras) | Datos + K + Ancho + Inicio |
| `DBOXPLOT` | Caja, bigotes, outliers, eje, puntos individuales | Datos |

En `DFRECTABLA`/`DHISTO`, los campos K/Ancho/Inicio en `0` = automático (Sturges).
Se pueden fijar a mano para reproducir ejercicios de cátedra que eligen K
arbitrariamente (ej. el de horas trabajadas usa K=5, Ancho=5, Inicio=10 — la
cátedra arranca en un entero cómodo *menor* al mínimo real).

### Relación entre dos variables

| Programa | Qué hace |
|---|---|
| `DCOVCORR` | Covarianza, r de Pearson, dispersión + recta de regresión |
| `DOLS` | Regresión lineal (b0, b1, r, R²) por sumatorias |

Ambos piden **dos listas separadas** (X e Y), no una matriz. Ambos usan `SIGFIG`.

### Economía

| Programa | Qué hace |
|---|---|
| `DMKT` | Equilibrio de mercado simple + gráfico |
| `DMKTFISC` | Completo: impuesto/subsidio, Pb/Ps, recaudación, PIE, incidencia, elasticidades, controles de precio (techo/piso) con escasez/excedente, gráfico con áreas sombreadas |
| `DCOMPFIRM` | Empresa competitiva: Q* por P=CMg, beneficio, cierre; gráfico CMg/CVMe/P |
| `DPIBPPA` | PIB per cápita PPA |
| `DTCAMBIO` | Tasa de crecimiento anual compuesta (CAGR) |
| `DVLRZ` (`DCOMPZ`) | Valor Z, clasifica atípico si \|Z\|>3 |

### Matemática

| Programa | Qué hace |
|---|---|
| `DTROZOS` | Grafica funciones a trozos, con extremos abiertos/cerrados marcados |

`DTROZOS`: pide ventana de gráfico, luego por tramo la expresión (`'X^2'`), y
cada extremo como `"<"` / `"<="` / vacío (sin límite) + su valor.

### Utilidad

| Programa | Qué hace |
|---|---|
| `SIGFIG` | Redondea a N cifras significativas. **DEBE estar en HOME**, no en subcarpeta, para que `DOLS`/`DCOVCORR` lo encuentren |

**Regla de scope:** `HOME` es visible desde cualquier subcarpeta (la búsqueda de
nombres sube). Entre carpetas hermanas NO hay visibilidad.

---

## 6. Datasets de prueba (cargados como variables en la calculadora)

| Variable | Contenido | Uso |
|---|---|---|
| `BM5X` / `BM5Y` | PIB pc PPA y precio Big Mac, 5 países | Par X/Y. `r ≈ 0.9781` |
| `BMHIST` | 45 precios Big Mac | Una variable. Moda: `5.31` (frec 3) |
| `BMSCX` / `BMSCY` | PIB y precio, 46 países | Par X/Y. `r ≈ 0.7579` |
| `HORAS` | 20 valores de horas trabajadas | K=5, Ancho=5, Inicio=10 → frec `2,2,6,6,4` |

**Se pueden usar escribiendo el nombre de la variable en el campo "Datos"** en
vez de tipear la lista entera. Confirmado que funciona.

### Casos de verificación conocidos

- `DSTATS` con `BM5X`: Media=32172.2, sX=32930.3
- `DCOVCORR` con `BM5X`/`BM5Y`: sXY=62909.8, r=0.9781 (valores del apunte de cátedra)
- `DOLS` con `BM5X`/`BM5Y`: `Y = 1.952 + 0.0000580*X`, r=0.9781 (debe coincidir con DCOVCORR)
- `DMKT` con a=100,b=2,c=10,d=3,T=0: P*=18, Q*=64. Con T=5: P*=21, Q*=58
- `DMKTFISC` con a=100,b=2,c=10,d=3,T=5: Ps=16, Recaud=290, PIE=15, Inc 60/40, Ed=-0.7241, Es=0.8276
- `DMKTFISC` subsidio a=60,b=4,c=0,d=2,T=-3: Pb=9, Ps=12, Q*=24, Recaud=-72, PIE=6
- `DCOMPFIRM` con CF=20,b=3,c=1: P=43→Q*=20,Ben=380 | P=11→Q*=4,Ben=-4 | P=1→cierra,Ben=-20
- `DPCTIL` con `{2,4,6,8,10}`: p50→6, p70→Lp=4.2, Valor=8.4

---

## 7. Pendientes

### Programas no hechos (priorizados)

1. **Modelo macro simple** — `Y=C+I+G` con `C=a+b(Y-T)`; ingreso de equilibrio y
   multiplicador. Cierra el último hueco explícito de la Unidad 6 del programa.
2. **Monopolio** — demanda lineal + costos, resolver por `IMg=CMg`. Es el patrón
   más repetido en el TP6 de Micro.
3. **Utilidad Cobb-Douglas** — `U=X^a·Y^b` con restricción presupuestaria.
4. Elasticidad arco (entre dos puntos arbitrarios), números índice,
   interpolación lineal.
5. **Matemática I** (cátedra Barraza): EDO separables, estudio de función,
   multiplicadores de Lagrange.

### Mejoras pendientes

- Probar el camino nativo `DRAX/DRAW/LABEL` (sección 2.9) — podría simplificar
  todos los gráficos y permitir rotular ejes.
- Alinear columnas de salida con padding de espacios donde se use texto.
- `DTROZOS` no tiene protección contra asíntotas/discontinuidades dentro de un
  tramo (ej. `1/X` con un tramo que cruce 0) — va a fallar o dar resultados sin
  sentido.

### Decisiones tomadas (no re-litigar)

- **No** calcular dominio/imagen automáticamente en `DTROZOS`: requiere
  matemática simbólica frágil, y el "dominio" resultante sería solo la ventana
  elegida, no el dominio matemático real. Se descartó a propósito.
- **No** parsear condiciones completas tipo `"si x < 2"`: implicaría un
  mini-parser de texto, demasiado frágil. Se optó por campos separados.
- Los gráficos usan la orientación de libro de texto donde corresponde
  (`DMKTFISC`: Precio vertical, Cantidad horizontal).
