# Programas — últimas versiones funcionales

Estos son los archivos listos para transferir con Conn4x. Ya están con header
`%%HP:`, CRLF y ASCII puro verificados. Ver `../CLAUDE.md` para el contexto
completo, las reglas de UserRPL y los casos de prueba.

## Orden de carga (importante)

1. **`SIGFIG.txt` primero, y guardarlo en `HOME`** (no dentro de una subcarpeta).
   No tiene envoltorio `DIR` a propósito: se guarda con `'SIGFIG' STO` en HOME.
   `DOLS` y `DCOVCORR` lo llaman por nombre y no lo encuentran si está en una
   carpeta hermana.
2. El resto en cualquier orden. Cada uno trae su propio `DIR` y cae como
   subcarpeta.
3. Los archivos de `datos/` son listas sueltas (sin `DIR`). Se guardan con
   `'NOMBRE' STO` y después se usan escribiendo el nombre de la variable en
   cualquier campo "Datos:".

## Estado de prueba en hardware

| Programa | Estado |
|---|---|
| `DSTATS`, `DPCTIL`, `DMODA`, `DFRECTABLA` | Verificado contra valores de cátedra |
| `DCOVCORR`, `DOLS` | Verificados; `r` coincide entre ambos (0.9781) |
| `DHISTO` | Verificado tras corregir bug de bloque huérfano |
| `DMKT`, `DMKTFISC`, `DCOMPFIRM` | Verificados con casos conocidos (ver CLAUDE.md §6) |
| `DPIBPPA`, `DTCAMBIO`, `DVLRZ` | Verificados |
| `DBOXPLOT` | Versión de coordenadas reales — **probar de nuevo**, se reescribió después de la última confirmación |
| `DTROZOS` | Versión con extremos `"<"` / `"<="` — **sin confirmar** en hardware |

## Convenciones de entrada

- Expresiones algebraicas: **con comillas simples** → `'X^2+3'`
- Símbolos de desigualdad en campos: **con comillas dobles** → `"<"` , `"<="`
- Campos K / Ancho / Inicio en `0` = cálculo automático
- En `DMKTFISC`, impuesto `T` negativo = subsidio (la "Recaudación" negativa se
  lee como costo fiscal)

## Salidas especiales

- `DFRECTABLA` deja una **matriz** en la pila. Para verla como planilla: pasar a
  **modo algebraico** y hacer `EDIT` sobre ella.
- El resto usa `MSGBOX` encadenados (apretar OK para avanzar entre cajas).
