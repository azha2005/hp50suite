# verificar.ps1 — Bateria de verificacion para programas UserRPL (HP 50g)
#
# Uso:
#   .\verificar.ps1 archivo.txt        (un archivo)
#   .\verificar.ps1 programas\*.txt    (varios)
#
# Si PowerShell bloquea el script:
#   powershell -ExecutionPolicy Bypass -File .\verificar.ps1 archivo.txt

param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Archivos)

if (-not $Archivos) {
    Write-Host "Uso: .\verificar.ps1 <archivo.txt> [mas archivos...]"
    exit 1
}

function Test-ArchivoRPL {
    param([string]$Ruta)

    if (-not (Test-Path $Ruta)) {
        Write-Host "NO EXISTE: $Ruta" -ForegroundColor Red
        return
    }

    $nombre    = Split-Path $Ruta -Leaf
    $bytes     = [System.IO.File]::ReadAllBytes($Ruta)
    $contenido = [System.IO.File]::ReadAllText($Ruta)
    $lineas    = $contenido -split "`r?`n"

    $problemas = @()

    # 1. Profundidad de anidacion acumulada (debe terminar en 0)
    $depth = 0; $maxd = 0
    foreach ($l in $lineas) {
        $ab = ([regex]::Matches($l, [regex]::Escape('\<<'))).Count
        $ce = ([regex]::Matches($l, [regex]::Escape('\>>'))).Count
        $depth += $ab - $ce
        if ($depth -gt $maxd) { $maxd = $depth }
    }
    if ($depth -ne 0) { $problemas += "Anidacion NO cierra (queda en $depth)" }

    # 2. Bloques \<< huerfanos (sin \-> en la linea anterior).
    #    El unico esperado es el que abre el programa.
    $huerfanos = @()
    for ($i = 1; $i -lt $lineas.Count; $i++) {
        if ($lineas[$i] -like '*\<<*' -and $lineas[$i-1] -notlike '*\->*') {
            $huerfanos += ($i + 1)
        }
    }
    if ($huerfanos.Count -gt 1) {
        $problemas += "Posibles bloques huerfanos en lineas: $($huerfanos -join ', ')"
    }

    # 3. Bytes no-ASCII (rompen la transferencia por Conn4x)
    $noAscii = ($bytes | Where-Object { $_ -gt 127 }).Count
    if ($noAscii -gt 0) { $problemas += "Tiene $noAscii bytes no-ASCII" }

    # 4. Comandos que no existen en UserRPL (ignorando comentarios @)
    $codigo = ($lineas | Where-Object { $_ -notmatch '^\s*@' }) -join "`n"
    foreach ($cmd in @('SQRT', 'ROUND', '>=', '=/=')) {
        if ($codigo -match [regex]::Escape($cmd)) {
            $problemas += "Usa comando invalido: $cmd"
        }
    }

    # 5. Comillas dobles balanceadas
    $comillas = ([regex]::Matches($contenido, '"')).Count
    if ($comillas % 2 -ne 0) { $problemas += "Comillas dobles impares ($comillas)" }

    # 6. Header %%HP y terminaciones CRLF
    if ($lineas[0] -notmatch '^%%HP:') { $problemas += "Falta el header %%HP en la primera linea" }
    if ($contenido -notmatch "`r`n")   { $problemas += "No tiene terminaciones CRLF" }

    # 7. Conteos informativos
    $ab  = ([regex]::Matches($contenido, [regex]::Escape('\<<'))).Count
    $ce  = ([regex]::Matches($contenido, [regex]::Escape('\>>'))).Count
    $for = ([regex]::Matches($codigo, '\bFOR\b')).Count
    $nxt = ([regex]::Matches($codigo, '\bNEXT\b')).Count
    if ($for -ne $nxt) { $problemas += "FOR ($for) y NEXT ($nxt) no coinciden" }

    if ($problemas.Count -eq 0) {
        Write-Host ("{0,-20} OK   (depth max {1}, {2}/{3} bloques, {4} FOR)" -f $nombre, $maxd, $ab, $ce, $for) -ForegroundColor Green
    } else {
        Write-Host ("{0,-20} PROBLEMAS:" -f $nombre) -ForegroundColor Red
        foreach ($p in $problemas) { Write-Host "    - $p" -ForegroundColor Yellow }
    }
}

foreach ($patron in $Archivos) {
    $encontrados = Get-ChildItem -Path $patron -ErrorAction SilentlyContinue
    if ($encontrados) {
        foreach ($f in $encontrados) { Test-ArchivoRPL $f.FullName }
    } else {
        Test-ArchivoRPL $patron
    }
}
